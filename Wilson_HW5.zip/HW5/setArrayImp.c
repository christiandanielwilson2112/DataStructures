#include <stdio.h>
#include <stdlib.h>
#include "genlib.h"
#include "set.h"

#define MAX_ELEMENTS 100

struct setCDT {
   int count;
   setElementT arr[MAX_ELEMENTS];
};

setADT setNew() {
 setADT set;
 set = New(setADT);
 set->count = set->arr[MAX_ELEMENTS] = 0;
 return(set);
} /* create a new empty set */

void setFree(setADT S){
   FreeBlock(S);
} /* free the space allocated for the set S */

int setInsertElementSorted(setADT S, setElementT E){
 int k, j, m; 
 if(S->count != MAX_ELEMENTS) {
    S->arr[S->count] = E;
    S->count++;
    
    for(k = 0; k < S->count - 1; k++) {
       m = k;
       for(j = k + 1; j < S->count; j++) 
         if(S->arr[j] < S->arr[m])
          m = j;

       int tmp = S->arr[m];
       S->arr[m] = S->arr[k];
       S->arr[k] = tmp;
      }
     return S->count; 
   } else
      return 0;
}
/* if not successful, return 0; otherwise, return the num of elements after the insertion.
Also note that the elements might be given in different orders, but your function should always
keep the set in a sorted manner after each insertion */

setADT setUnion(setADT A, setADT B) {

int i = 0;
int j = 0;
int k = 0;
setADT C;
C = setNew();

         while ((i < A->count) && (j < B->count)) {
           if (A->arr[i] < B->arr[j]) {
            C->arr[k] = A->arr[i];
            i++;
            k++;
        } else if (A->arr[i] > B->arr[j]) {
            C->arr[k] = B->arr[j];
            j++;
            k++;
        } else {
            C->arr[k] = A->arr[i];
            i++;
            j++;
            k++;
        }
    } 
       if (i == A->count) {
        while (j < B->count) {
            C->arr[k] = B->arr[j];
            j++;
            k++;
        }
    } else {
        while (i < A->count) {
            C->arr[k] = A->arr[i];
            i++;
            k++;
        }
    }
    C->count = k;
    return C;
}

/* returns a new set containing A ∪ B */

setADT setIntersection(setADT A, setADT B) {

int i = 0;
int j = 0;
int k = 0;
setADT C;
C = setNew();

 while ((i < A->count) && (j < B->count)) {
        if (A->arr[i] < B->arr[j]) {
            i++;
        } else if (A->arr[i] > B->arr[j]) {
            j++;
        } else { 
           C->arr[k] = A->arr[i];
            i++;
            j++;
            k++;
        }
       }
    C->count = k;
    return C;
}
/* returns a new set containing A ∩ B */

setADT setDifference(setADT A, setADT B){

int i;
int j;
int k = 0;
setADT C;
C = setNew();
int flag;

	for(i = 0; i < A->count; i++) {
        flag = 1;
	   for(j = 0; j < B->count; j++) {
             if(A->arr[i] == B->arr[j]) {
                flag = 0;
                break;
             }
           } 
              if(flag == 1) {
              C->arr[k] = A->arr[i];
              k++;
           } 
        }    

C->count = k;
return C;
}
/* returns a new set containing A \ B */

int setCardinality(setADT S){
     return S->count;
} /* return the number of elements in S */

void setPrint(setADT S, char *name){
  printf("%s = {", name);
  int i = 0;
  while(i < S->count - 1) {
  printf("%d, ", S->arr[i]);
  i++;
 }
 printf("%d}\n", S->arr[i]);
} /* print elements of S */
