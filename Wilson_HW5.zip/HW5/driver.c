/*
 * File: driver.c
 * --------------
 * The driver reads and executes simple commands entered by the user.
 */

#include <stdio.h>
#include <ctype.h>
#include "genlib.h"
#include "set.h"
#include "simpio.h"

#define MAX 100
/* Private function prototypes */

setADT ExecuteCommand(setADT A, setADT B, setADT C, char c);
static void HelpCommand(void);

/* Main program */

main()
{
    setADT A;
    setADT B;
    setADT C;

    A = setNew();
    B = setNew();
    C = setNew();

    char c;
    int i, j;
    setElementT k = 0;
 
    printf("Enter positive integers for set A:");
    for(i = 0; i < MAX; i++) {
    scanf("%d", &k);
    if(k == -1)  
     break;
    else 
     setInsertElementSorted(A, k);
   }
   
    printf("Enter positive integers for set B:");
    for(j = 0; j < MAX; j++) {
    scanf("%d", &k);
    if(k == -1)
     break;
    else
     setInsertElementSorted(B, k);
    }

    while (TRUE) {
        printf("*");
        scanf(" %c", &c);
        C = ExecuteCommand(A, B, C, c);
        setPrint(A, "A");
        setPrint(B, "B");
        setPrint(C, "C");
        printf("%d\n", setCardinality(C));
        setFree(C);
    }
    setFree(A);
    setFree(B);
}

/*
 * Function: ExecuteCommand
 * Usage: ExecuteCommand(A, B, line);
 * ------------------------------------
 * This function parses the user command in the string line
 * and executes it on the set.
 */

setADT ExecuteCommand(setADT A, setADT B, setADT C, char c) {

    switch (toupper(c)) {
      case 'U': C = setUnion(A, B); break;
      case 'I': C = setIntersection(A, B); break;
      case 'D': C = setDifference(A, B); break;
      case 'H': HelpCommand(); break;
      case 'Q': exit(0);
      default:  printf("Illegal command\n"); break;
    }
  return C;
}

/*
 * Function: HelpCommand
 * Usage: HelpCommand();
 * ---------------------
 * This function lists the available editor commands.
 */

static void HelpCommand(void)
{
    printf("Use the following commands to implement on Set:\n");
    printf("  U      Shows the union Set A and B\n");
    printf("  I      Shows the intersection of Set A and B\n");
    printf("  D      Shows the difference of Set A and B\n");
    printf("  H      Generates a help message\n");
    printf("  Q      Quits the program\n");
}
