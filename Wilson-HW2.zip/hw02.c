#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//declaring number of rows and columns in array g
#define ROW 3
#define COL 4

//function prototypes
char ** mallocChar(int col, int row);
void fillChar(int col, int row, FILE *f, char **arr);
void wordsearch(int col, int row, int argc, char **argv, char **arr);

int searchHorizontally(int x, int y, int z, char **argv, char **a) {
int i, temp;
temp = strlen(argv[z]);
for(i = 0; i < temp; i++) {
if(argv[z][i] == a[y][x]) {
	x++;
	continue;
	}else{
	return 0;
}
}
return 1;
}


int searchVertically(int x, int y, int z, char **argv, char **a) {
int i, temp;
temp = strlen(argv[z]);
for(i = 0; i < temp; i++) {
if(argv[z][i] == a[y][x]) {
        y++;
        continue;
        }else{
        return 0;
}
}
return 1;
}

int searchDiagonally(int x, int y, int z, char **argv, char **a) {
int i, temp;
temp = strlen(argv[z]);
for(i = 0; i < temp; i++) {
if(argv[z][i] == a[y][x]) {
        x++;
	y++;
        continue;
        }else{
        return 0;
}
}
return 1;
}

//execution starts here
main(int argc, char *argv[]) {

	int i, j, row, col;
	FILE * f;
	char **arr, *p[ROW];
 	char g[ROW][COL] = { {'a','b','c','d'},
		    	   {'d','c','b','a'},
		      	   {'x','y','z','d'}
		     }; 
	if(strcmp(argv[argc-2], "-f") == 0) {
	f = fopen(argv[argc-1], "r");
	fscanf(f, "%d %d", &row, &col);
	arr = mallocChar(col, row);
	fillChar(col, row, f, arr);
	fclose(f);
	wordsearch(col, row, argc-2, argv, arr);
	free(arr);
} else {
	for(i = 0; i < ROW; i++)
	p[i] = &g[i][0];
	wordsearch(COL, ROW, argc, argv, p);
}
}

char ** mallocChar(int col, int row) {
	int i;
	char **arr = (char**)malloc(row*sizeof(char*));
	if(arr == NULL) {
	printf("No memory available.");
	exit(0);
	}

	for(i = 0; i < row; i++) {
	arr[i] = (char *)malloc(col*sizeof(char));
	if(arr[i] == NULL) {
	printf("No memory available.");
	exit(0);
}
}	
return arr;
}

void fillChar(int col, int row, FILE *f, char **arr) {
int i, j;
while(feof(f) == 0) {
	for(i = 0; i < row; i++) {
	for(j = 0; j < col; j++) {
	fscanf(f, "%c ", &arr[i][j]);
}
}
}
}

void wordsearch(int col, int row, int argc, char **argv, char **arr) {
int i, j, k;

for(k = 1; k < argc; k++) {
	for(i = 0; i < row; i++) {
		for(j = 0; j < col; j++) {
if(arr[i][j] == *argv[k]) {
if(searchHorizontally(j, i, k, argv, arr) == 1) {
 printf("%s appears horizontally starting at g[%d][%d] \n", argv[k], i, j);
	i = row;
	break;
} else 
if(searchVertically(j, i, k, argv, arr) == 1) {
 printf("%s appears vertically starting at g[%d][%d] \n", argv[k], i, j);
	i = row;
	break;
} else
if(searchDiagonally(j, i, k, argv, arr) == 1) {
 printf("%s appears diagonally starting at g[%d][%d] \n", argv[k], i, j);
	i = row;
	break;
}
}
//print statements based on search functions' truth values
if(j + 1 == col && i + 1 == row) {
	printf("%s does not appear in g \n", argv[k]);
}
}
}
}
}
