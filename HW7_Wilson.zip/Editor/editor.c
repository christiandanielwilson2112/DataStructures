/*
 * File: editor.c
 * --------------
 * This program implements a simple character editor, which
 * is used to test the buffer abstraction.  The editor reads
 * and executes simple commands entered by the user.
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "genlib.h"
#include "simpio.h"

 typedef struct nodeT {
  int key;
  struct nodeT *left, *right;
 } nodeT;
  
 typedef nodeT *treeT;
 
/* Private function prototypes */

static void ExecuteCommand(nodeT *tree, string line);
static void HelpCommand(void);
nodeT *NewTree(); 
void FreeTree(nodeT *tree);
void Insert(nodeT **tree, int key); 
nodeT *Find(nodeT *tree, int key); 
void DeleteHelper(nodeT **p, int key);
void Delete(nodeT **tree);
void InOrder(nodeT *tree); 
void PreOrder(nodeT *tree);
void PostOrder(nodeT *tree); 
void LevelOrder(nodeT *tree); 
void printGivenLevel(nodeT *tree, int level); 
int Max(nodeT *tree); 
int Min(nodeT *tree); 
int Height(nodeT *tree); 
int Count(nodeT *tree); 
int Sum(nodeT *tree); 

int maximumof(int a, int b);

/* Main program */

main()
{
    nodeT *tree;

    tree = NewTree();
    while (TRUE) {
        printf("*");
        ExecuteCommand(tree, GetLine());
        printf("\n");
    }
    FreeTree(tree);
}

/*
 * Function: ExecuteCommand
 * Usage: ExecuteCommand(buffer, line);
 * ------------------------------------
 * This function parses the user command in the string line
 * and executes it on the buffer.
 */

static void ExecuteCommand(nodeT *tree, string line)
{
    char *token, *key;
    token = strtok(line, " ");

    switch (toupper(line[0])) {
      case 'I': while(token) {
                    key = strtok(NULL, " ");
                    if(key == NULL) break;
                    Insert(&tree, atoi(key));
                }
                break;
      case 'F': while(token) { 
                 key = strtok(NULL, " ");
                 if(key == NULL) break; 
                 Find(tree, atoi(key)); 
                 }
                 break;
      case 'D': while(token) { 
                     key = strtok(NULL, " ");
                     if(key == NULL) break;
                     DeleteHelper(&tree, atoi(key)); 
                }
                break;
      case 'O': InOrder(tree); break;
      case 'B': PreOrder(tree); break;
      case 'A': PostOrder(tree); break;
      case 'L': LevelOrder(tree); break;
      case 'X': printf("%d ", Max(tree)); break;
      case 'N': printf("%d ", Min(tree)); break;
      case 'T': printf("%d ", Height(tree)); break;
      case 'C': printf("%d ", Count(tree)); break;
      case 'S': printf("%d ", Sum(tree)); break;
      case 'H': HelpCommand(); break;
      case 'Q': exit(0);
      default:  printf("Illegal command\n"); break;
    }
}

/*
 * Function: HelpCommand
 * Usage: HelpCommand();
 * ---------------------
 * This function lists the available editor commands.
 */

static void HelpCommand(void)
{
    printf("Use the following commands to edit the buffer:\n");
    printf("  I...   Inserts text up to the end of the line\n");
    printf("  F...   Finds specific int\n");
    printf("  D...   Deletes specific int\n");
    printf("  O      Prints tree in order\n");
    printf("  B      Prints tree preorder\n");
    printf("  A      Prints tree postorder\n");
    printf("  L      Prints tree level order\n");
    printf("  X      Returns max int of tree\n");
    printf("  N      Returns min int of tree\n");
    printf("  T      Returns height of tree\n");
    printf("  C      Returns count of ints of tree\n");
    printf("  S      Returns sum of ints of tree\n");
    printf("  H      Generates a help message\n");
    printf("  Q      Quits the program\n");
}

nodeT *NewTree()
{
    nodeT *t;
    t = New(nodeT *);
    t->left = NULL;
    t->right = NULL;

    return(t);
}

void FreeTree(nodeT *tree) 
{
    if(tree == NULL) return;
    FreeTree(tree->left);
    FreeTree(tree->right);
    FreeBlock(tree);
}

void Insert(nodeT **tree, int key) 
{ 
  nodeT *t, *tmp;
  t = *tree; 
  if(t == NULL) {
    tmp = New(nodeT *);
    tmp->key = key;
    tmp->left = NULL;
    tmp->right = NULL;    
    *tree = tmp;
    return;
  }

  if(t->key == 0 && t->left == NULL && t->right == NULL) {
     t->key = key;
     return;
     }

  if(key < t->key) {
    Insert(&t->left, key);
  } else {
    Insert(&t->right, key);
  }
}

nodeT *Find(nodeT *tree, int key)
{
 while(tree != NULL) {
   if(key == tree->key) {
     printf("Found %d\n", tree->key);
     return tree;
     }

   if(key < tree->key) {
      tree = tree->left;
   } else { 
      tree = tree->right;
   }
  } 
  return NULL;
}

void DeleteHelper(nodeT **p, int key) 
{
 while((*p) != NULL) {
  if((*p)->key == key)
         break;
  if((*p)->key < key)
     p = &((*p)->right);
  else
     p = &((*p)->left);   
   }

   if((*p) != NULL)
     Delete(p);
}

void Delete(nodeT **p) 
{      
  nodeT *target, *lmd_r, *plmd_r;
  target = *p;
  if(target->left == NULL && target->right == NULL) {
    *p = NULL;
  } else if(target->left == NULL) {
    *p = target->right;
  } else if(target->right == NULL) {
    *p = target->left;
  } else { 
    plmd_r = target;
    lmd_r = target->right;
    while(lmd_r->left != NULL) {
     plmd_r = lmd_r;
     lmd_r = lmd_r->left;
    }
    if(plmd_r == target)
       plmd_r->right = lmd_r->right;
    else 
       plmd_r->left = lmd_r->right;
      lmd_r->left = target->left;
      lmd_r->right = target->right;
      *p = lmd_r;  
   }
  free(target); 
}

void InOrder(nodeT *tree) 
{ 
 if(tree != NULL) {
   InOrder(tree->left);
   printf("%d ", tree->key);
   InOrder(tree->right);
  } 
}

void PreOrder(nodeT *tree) 
{
 if(tree != NULL) {
   printf("%d ", tree->key);
   PreOrder(tree->left);
   PreOrder(tree->right);
  }
}

void PostOrder(nodeT *tree)
{  
 if(tree != NULL) {
   PostOrder(tree->left);
   PostOrder(tree->right);
   printf("%d ", tree->key);
  }
}
 
void LevelOrder(nodeT *tree) 
{
    int h = Height(tree);
    int i;
    for (i = 1; i <= h; i++)
        printGivenLevel(tree, i);
}
 
void printGivenLevel(nodeT *tree, int level) 
{
    if (tree == NULL)
        return;
    if (level == 1)
        printf("%d ", tree->key);
    else if (level > 1)
    {
        printGivenLevel(tree->left, level-1);
        printGivenLevel(tree->right, level-1);
    }
}

int Max(nodeT *tree) 
{
 while(tree->right != NULL) {
    tree = tree->right;
  }
  return tree->key;
}

int Min(nodeT *tree) 
{ 
 while(tree->left != NULL){
    tree = tree->left;
   }
   return tree->key;
}

int Height(nodeT *tree) 
{
 if(tree == NULL)
    return 0;
 else 
    return(1 + maximumof(Height(tree->left), Height(tree->right)));
}

int maximumof(int a, int b) 
{
 if(a > b) return a;
 else return b;
}


int Count(nodeT *tree)
{
  if(tree == NULL) return 0; 
  return(1 + Count(tree->left) + Count(tree->right));
}

int Sum(nodeT *tree) 
{ 
 if(tree == NULL)
   return 0;
 else 
   return (tree->key + Sum(tree->left) + Sum(tree->right));
}
