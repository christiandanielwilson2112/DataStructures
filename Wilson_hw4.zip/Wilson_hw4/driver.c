#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "stack.h"


main(int argc, char *argv[]) {
 FILE *fp;

 stackADT stack1;
 char *tag;
 char c;
 int i;
 int j;
 int size;
 stack1 = NewStack();
 char tmp[25]; 
 int count;
 
if(argc == 2) {

 fp = fopen(argv[1], "r");
 if(fp == NULL) exit(-1);

 while(!feof(fp)) {
  fscanf(fp, "%c", &c);
   if(c == '<') {
    fscanf(fp, "%c", &c);
     if(c == '/') {
     for(i = 0; c != '>'; i++) {
      fscanf(fp, "%c", &c);
      tmp[i] = c;
      }//ends for
      size = i;
      tag = Pop(stack1);
      for(j = 0; j < size - 1 && tag[j] != '>'; j++) {
      if(tag[j + 1] == tmp[j]) {
      continue;
      } else {
      printf("Tags %s </", tag); 
      for(i = 0; i < size; i++) 
      printf("%c", tmp[i]);  
      break;
      }//ends else
      }//ends for 
      if(j == size - 1) { 
      free(tag);
      continue;
      }//ends if
      free(tag);
      while(!StackIsEmpty(stack1)) {
      tag = Pop(stack1);
      free(tag);
      }//ends while
      break;
    }//ends if 
   if(c == '!') {
    count = 0; 
     for(i = 0; c != '>' || count != 4; i++) {
     fscanf(fp, "%c", &c);
      if(c == '-') {
      count++;
  }//ends if
}//ends for
     continue;
}//ends if
   tmp[0] = '<';
   tmp[1] = c;
   for(i = 2; c != '>'; i++) {
      fscanf(fp, "%c", &c);
      tmp[i] = c;
      }//ends for
   if(tmp[i-2] == '/') continue;
   tag = malloc(sizeof(char)*i);
   for(j = 0; j < i; j++) {
   tag[j] = tmp[j];
   }//ends for
   Push(stack1, tag);
   continue;
}//ends if <
}//ends while

 if(feof(fp)) {
  printf("Tags are properly nested.\n");
 } else {
  printf(" violates proper nesting.\n");
  }//ends else
  fclose(fp);
 FreeStack(stack1);
}//ends if
 return;
}//ends main
