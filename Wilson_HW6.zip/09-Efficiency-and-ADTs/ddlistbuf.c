/*
 * File: ddlistbuf.c
 * ---------------
 * This file implements the buffer.h abstraction using a linked
 * list to represent the buffer.
 */

#include <stdio.h>
#include "genlib.h"
#include "strlib.h"
#include "buffer.h"

#define MAX_ARRAY_SIZE 4

/* Types */

typedef struct cellT {
    struct cellT *link;
    struct cellT *prev;
    int n;
    char arr[MAX_ARRAY_SIZE];
} cellT;

struct bufferCDT {
    cellT *start;
    cellT *cursor;
    int c_pos;
};

/*
 * Implementation notes: NewBuffer
 * -------------------------------
 * This function allocates an empty editor buffer, represented
 * as a linked list.  To simplify the link list operation, this
 * implementation adopts the useful programming tactic of
 * keeping an extra "dummy" cell at the beginning of each list,
 * so that the empty buffer has the following representation:
 *
 *     +-------+          +------+
 *     |   o---+-----====>|      |
 *     +-------+    /     +------+
 *     |   o---+---/      | NULL |
 *     +-------+          +------+
 */

bufferADT NewBuffer(void)
{
    bufferADT buffer;

    buffer = New(bufferADT);
    buffer->start = buffer->cursor = New(cellT *);
    buffer->start->link = buffer->start->prev = buffer->start;
    buffer->start->n = 0;
    buffer->c_pos = 0;
    return (buffer);
}

/*
 * Implementation notes: FreeBuffer
 * --------------------------------
 * FreeBuffer must free every cell in the buffer as well as
 * the buffer storage itself.  Note that the loop structure
 * is not exactly the standard idiom for processing every
 * cell within a linked list, because it is not legal to
 * free a cell and later look at its link field.  To avoid
 * selecting fields in the structure after it has been freed,
 * you have to copy the link pointer before calling FreeBlock.
 */

void FreeBuffer(bufferADT buffer)
{
    cellT *cp, *next;

    cp = buffer->start;
    while (cp->link != buffer->start) {
        next = cp->link;
        FreeBlock(cp);
        cp = next;
    }
    FreeBlock(buffer);
}

/*
 * Implementation notes: MoveCursorForward
 * ---------------------------------------
 * This function moves cursor forward. 
 */
void MoveCursorForward(bufferADT buffer)
{
    if (buffer->c_pos != buffer->cursor->n) {
       buffer->c_pos++;
    } else if(buffer->cursor->link != buffer->start) {
           buffer->cursor = buffer->cursor->link;
           buffer->c_pos = 1;
   }
}

/*
 * Implementation notes: MoveCursorBackward
 * ----------------------------------------
 * This function moves cursor backward.
 */
void MoveCursorBackward(bufferADT buffer)
{
    if (buffer->c_pos != 0) {
       buffer->c_pos--;
    } else if(buffer->cursor != buffer->start) {
              buffer->cursor = buffer->cursor->prev;
              buffer->c_pos = buffer->cursor->n - 1;
      }
}

/*
 * Implementation notes: MoveCursorToStart
 * --------------------------------------
 * This function moves cursor to start.
 */
void MoveCursorToStart(bufferADT buffer)
{
    buffer->cursor = buffer->start;
    buffer->c_pos = 0;
}

/*
 * Implementation notes: MoveCursorToEnd
 * -------------------------------------
 * This function moves cursor to end.
 */
void MoveCursorToEnd(bufferADT buffer)
{
   buffer->cursor = buffer->start->prev;
   buffer->c_pos = buffer->cursor->n;
}

/*
 * Implementation notes: InsertCharacter
 * -------------------------------------
 * This function inserts characters into the buffer.
 */
void InsertCharacter(bufferADT buffer, char ch)
{
cellT *nc;
int i;
    if(buffer->cursor->n == MAX_ARRAY_SIZE) {
        nc = New(cellT *);
        nc->prev = buffer->cursor;
        nc->link = buffer->cursor->link;
        buffer->cursor->link->prev = nc;
        buffer->cursor->link = nc;
        buffer->cursor->n = nc->n = MAX_ARRAY_SIZE/2;
        for(i = 0; i < nc->n; i++){
        nc->arr[i] = buffer->cursor->arr[i + nc->n];
        } 
     if(buffer->c_pos > MAX_ARRAY_SIZE / 2) {
      buffer->cursor = nc; 
      buffer->c_pos = buffer->c_pos - nc->n;
       } 
      }  

   for(i = buffer->cursor->n; i > buffer->c_pos; i--) {
       buffer->cursor->arr[i] = buffer->cursor->arr[i-1];
    }

   buffer->cursor->arr[buffer->c_pos] = ch;
   buffer->cursor->n++;
   buffer->c_pos++;
}

/*
 * Implementation notes: DeleteCharacter
 * -------------------------------------
 * This function deletes characters from the buffer.
 */
void DeleteCharacter(bufferADT buffer)
{
    cellT *cp;
     
    int i;
    if (buffer->c_pos < buffer->cursor->n) {
       for (i = buffer->c_pos + 1; i < buffer->cursor->n; i++) {
          buffer->cursor->arr[i - 1] = buffer->cursor->arr[i];
            }
          buffer->cursor->n--;
          MoveCursorForward(buffer);
          MoveCursorBackward(buffer);
      }  
  
    if (buffer->cursor->link != buffer->start && buffer->cursor->n == 0) {
        cp = buffer->cursor->link;
        buffer->cursor->link = cp->link;
        cp->link->prev = buffer->cursor;
        FreeBlock(cp);
    }
}

/*
 * Implementation notes: DisplayBuffer
 * -------------------------------------
 * This function writes the buffer and cursor to console.
 */
void DisplayBuffer(bufferADT buffer)
{
    cellT *cp;
    int i = 0;
    cp = buffer->start;
    for(i = 0; i < cp->n; i++)
     printf(" %c", cp->arr[i]);

    for(cp = cp->link; cp != buffer->start; cp = cp->link) {
      for(i = 0; i < cp->n; i++)
      printf(" %c", cp->arr[i]);
    }
    printf("\n");
    cp = buffer->start;
   do{
    if(cp != buffer->cursor) {
    for(i = 0; i < cp->n; i++)
         printf("  ");
    } else {
       for(i = 0; i < buffer->c_pos; i++) 
         printf("  ");
         break;
    }
    cp = cp->link;
   }while(cp != buffer->start);
    printf("^\n");
}
