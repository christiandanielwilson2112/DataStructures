#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//check solution function
void checkSolution(int a[][9]) {
int UserChoice, i, j;
for(i = 0; i < 9; i++) {
    for(j = 0; j < 9; i++) {
	printf("Enter a digit from 1-9: ");
        scanf("%d", &UserChoice);
	if(UserChoice <= 0 || UserChoice >= 10)
        return;
        if(a[i][j] == 0) {
        a[i][j] = UserChoice;
}
}
}
}

//enter puzzle function
void enterPuzzle(int a[][9]) {
int UserChoice, i, j;
for(i = 0; i < 9; i++) {
    for(j = 0; j < 9; j++) {
	printf("Enter a digit from 0-9: ");
	scanf("%d", &UserChoice);
	if(UserChoice < 0 || UserChoice >= 10) 
	return;
	a[i][j] = UserChoice;
}
}
for(i = 0; i < 9; i++) {
    for(j = 0; j < 9; j++) {
	if(a[i][j] == 0) {
	printf("[%d][%d]: \n", i, j);
}
}
}
}

//program starts here
int main() {
int numbers[9];
int i;
for(i = 0; i < 9; i++) {
numbers[i] = i + 1;
}

int sudoku[9][9];
int UserChoice;
printf("Enter 1 to enter a puzzle or 2 to check a solution: ");
scanf("%d", &UserChoice);
if(UserChoice == 1) 
	enterPuzzle(sudoku);
if(UserChoice == 2)
	checkSolution(sudoku);
 

return(0);
}
